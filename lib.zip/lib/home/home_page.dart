import 'package:flutter/material.dart';
import 'package:flutter_testapp/auth/login_response.dart';

class HomeScreen extends StatefulWidget {
  final LoginResponse loginResponse;

  const HomeScreen({super.key, required this.loginResponse});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  var loginResponse;
  @override
  void initState() {
    loginResponse = widget.loginResponse;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home Page"),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
              child:
                  loginResponse != null ? Text(loginResponse.user) : Text("")),
        ],
      ),
    );
  }
}
