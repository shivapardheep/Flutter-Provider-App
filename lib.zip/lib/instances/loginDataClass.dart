class LoginDataClass {
  final String email;
  final String password;

  LoginDataClass(this.email, this.password);
}
