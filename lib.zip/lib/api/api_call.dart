import 'dart:convert';

import 'package:flutter_testapp/api/datas.dart';
import 'package:flutter_testapp/auth/login_response.dart';
import 'package:flutter_testapp/instances/loginDataClass.dart';
import 'package:http/http.dart' as http;

class ApiCall {
  loginFun(LoginDataClass obj) async {
    print(obj.email);
    print(obj.password);
    ApiData apiData = ApiData();
    var url = "${ApiData.loginApi}email=${obj.email}&password=${obj.password}";
    print("url is : ${url.toString()}");

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      print("response is : ${data.toString()}");
      LoginResponse loginResponse = LoginResponse.fromJson(data);
      return loginResponse;
    } else {
      var data = jsonDecode(response.body);
      LoginResponse loginResponse = LoginResponse.fromJson(data);
      return loginResponse;
    }
  }
}
