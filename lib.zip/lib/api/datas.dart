class ApiData {
  static const loginApi =
      "https://canvasapi1.azurewebsites.net/api/v1/loginapi?";
  static const emailId = "demo@campus.technology";
  static const password = "Password@123";
}
